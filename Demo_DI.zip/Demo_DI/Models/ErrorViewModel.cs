using System;

namespace Demo_DI.Models
{
    public class ErrorViewModel
    {
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
    public interface IHelloWorldService
    {
        string SaysHello();
    }

    public class HelloWorldService : IHelloWorldService
    {
        public string SaysHello()
        {
            return "Hello ";
        }
    }
}

